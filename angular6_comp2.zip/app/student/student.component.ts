import { Component, OnInit, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'app-student',
  templateUrl: './student.component.html',
  styleUrls: ['./student.component.css']
})
export class StudentComponent implements OnInit {
  @Input() name:string;
 @Input()rollno:Number;
 @Input()batch:String;
 @Output()sendStudent:EventEmitter<any>=new EventEmitter;
  selectStudent(){
    let selectedStud:any={srollno:this.rollno,sname:this.name,sbatch:this.batch};
    this.sendStudent.emit(selectedStud);
  }
  constructor() { }

  ngOnInit() {
  }

}
