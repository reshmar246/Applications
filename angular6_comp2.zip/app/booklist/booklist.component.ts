import { Component, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';

@Component({
  selector: 'app-booklist',
  templateUrl: './booklist.component.html',
  styleUrls: ['./booklist.component.css']
})
export class BooklistComponent implements OnInit {
public bookDetails:any=[{title:"book1",author:"author1",publisher:"publisher1"},
{title:"book2",author:"author2",publisher:"publisher2"},{title:"book3",author:"author3",publisher:"publisher3"}];
  
sellBook:any;
addBook(data:any){
  this.sellBook=data;

  }
constructor() { }

  ngOnInit() {
  }

}
