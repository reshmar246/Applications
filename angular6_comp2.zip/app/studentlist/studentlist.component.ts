import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-studentlist',
  templateUrl: './studentlist.component.html',
  styleUrls: ['./studentlist.component.css']
})
export class StudentlistComponent implements OnInit {
  public studentDetails:any=[{rollno:"1",name:"manu",batch:"mca"},
  {rollno:"2",name:"anu",batch:"mca"},{rollno:"3",name:"sanu",batch:"mca"}];
    
  sellStud:any;
  addStud(data:any){
    this.sellStud=data;
  
    }
  constructor() { }

  ngOnInit() {
  }

}
